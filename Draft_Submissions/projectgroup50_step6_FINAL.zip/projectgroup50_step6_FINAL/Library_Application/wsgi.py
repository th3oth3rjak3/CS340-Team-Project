""" This module runs the app in a production environment. """

from app import app

if __name__ == '__main__':
    app.run()
