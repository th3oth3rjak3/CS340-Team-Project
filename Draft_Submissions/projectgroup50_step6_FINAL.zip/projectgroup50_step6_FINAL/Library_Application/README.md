Database project for CS340 Spring 2022.

Owners - Jacob Hathaway & Kevin Kraatz
