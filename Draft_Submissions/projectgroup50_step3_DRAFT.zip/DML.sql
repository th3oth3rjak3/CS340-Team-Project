-- Jake Hathaway and Kevin Kraatz
-- User input in all queries is denoted by :attribute_input

-- Query for retrieving a supplier from the Suppliers page
SELECT supplier_id, name, address, phone_number FROM Suppliers
WHERE supplier_id = :supplier_id_input
ORDER BY supplier_id ASC;

-- Query for retrieving an employee from the Employees page
SELECT employee_id, first_name, last_name, phone_number, address FROM Employees
WHERE employee_id = :employee_id_input
ORDER BY employee_id ASC;

-- Query for retrieving an item from the Media_Items page
-- As different media can share titles, the media type and title must be specified
SELECT item_id, media_type, Suppliers.supplier_id, title, Creators.creator_id, 
release_date, replacement_cost, quantity_owned FROM Media_Items
INNER JOIN Suppliers ON Media_Items.supplier_id = Suppliers.supplier_id
INNER JOIN Creators ON Media_Items.creator_id = Creators.creator_id
WHERE title = :title_input AND media_type = :media_type_input
ORDER BY item_id ASC;

-- Query for retrieving a creator (author, artist, director, etc.) from the Creators page
SELECT creator_id, full_name FROM Creators
WHERE creator_id = :creator_id_input
ORDER BY creator_id ASC;

-- Query for retrieving a patron from the Patrons page
SELECT patron_id, first_name, last_name, phone_number, fine_amount, address FROM Patrons
WHERE patron_id = :patron_id_input
ORDER BY patron_id ASC;

-- Query for retrieving all transaction history from the Media_Transactions page
SELECT * FROM Media_Transactions
INNER JOIN Patrons ON Media_Transactions.patron_id = Patrons.patron_id
INNER JOIN Employees ON Media_Transactions.employee_id = Employees.employee_id
INNER JOIN Media_Items ON Media_Transactions.item_id = Media_Items.item_id
ORDER BY transaction_id ASC;

-- Query for retrieving a single transaction from the Media_Transactions page
SELECT transaction_id, Patrons.patron_id, transaction_type, Employees.employee_id, Media_Items.item_id, 
transaction_date FROM Media_Transactions
INNER JOIN Patrons ON Media_Transactions.patron_id = Patrons.patron_id
INNER JOIN Employees ON Media_Transactions.employee_id = Employees.employee_id
INNER JOIN Media_Items ON Media_Transactions.item_id = Media_Items.item_id
WHERE transaction_id = :transaction_id_input
ORDER BY transaction_id ASC;

-------------------------------------------------------------------------------------------------------------------------

-- Query for creating a new supplier on the Suppliers page
INSERT INTO Suppliers (name, address, phone_number)
VALUES (:name_input, :address_input, :phone_number_input);

-- Query for creating a new employee on the Employees page
INSERT INTO Employees (first_name, last_name, phone_number, address)
VALUES (:first_name_input, :last_name_input, :phone_number_input, :address_input);

-- Query for creating a new media item on the Media_Items page
INSERT INTO Media_Items (media_type, supplier_id, title, creator_id, 
release_date, replacement_cost, quantity_owned)
VALUES (:media_type_from_dropdown_input, :supplier_id_input, :title_input, 
:creator_id_input, :release_date_input, :replacement_cost_input, :quantity_owned_input);

-- Query for creating a new creator on the Creators page
INSERT INTO Creators (full_name)
VALUES (:full_name_input);

-- Query for creating a new patron on the Patrons page
INSERT INTO Patrons (first_name, last_name, phone_number, fine_amount, address)
VALUES (:first_name_input, :last_name_input, :phone_number_input, :fine_amount_input, :address_input);

-- Query for creating a new transaction on the Media_Transactions page
-- Associating a patron with a media item (M:N relationship addition)
INSERT INTO Media_Transactions (patron_id, transaction_type, employee_id, item_id)
VALUES (:patron_id_input, :transaction_type_from_dropdown_input, :employee_id_input, :item_id_input);

-------------------------------------------------------------------------------------------------------------------------

-- Query for updating a supplier from the Suppliers page
UPDATE Suppliers
SET name = :name_input, address = :address_input, phone_number = :phone_number_input
WHERE supplier_id = :supplier_id_from_update;

-- Query for updating an employee from the Employees page
UPDATE Employees
SET first_name = :first_name_input, last_name = :last_name_input, phone_number = :phone_number_input, address = :address_input
WHERE employee_id = :employee_id_from_update;

-- Query for updating an item from the Media_Items page
UPDATE Media_Items
SET media_type = :media_type_from_dropdown_input, supplier_id = :supplier_id_input, title = :title_input, 
creator_id = :creator_id_input, release_date = :release_date_input, replacement_cost = :replacement_cost_input, 
quantity_owned = :quantity_owned_input
WHERE item_id = :item_id_from_update;

-- Query for updating a creator from the Creators page
UPDATE Creators
SET full_name = :full_name_input
WHERE creator_id = :creator_id_from_update;

-- Query for updating a patron from the Patrons page
UPDATE Patrons
SET first_name = :first_name_input, last_name = :last_name_input, phone_number = :phone_number_input, 
fine_amount = :fine_amount_input, address = :address_input
WHERE patron_id = :patron_id_from_update;

-- Query for updating a transaction from the Media_Transactions page
UPDATE Media_Transactions
SET patron_id = :patron_id_input, transaction_type = :transaction_type_from_dropdown_input, 
employee_id = :employee_id_input, item_id = :item_id_input, transaction_date = :transaction_date_from_datetime_input
WHERE transaction_id = :transaction_id_from_update;

-------------------------------------------------------------------------------------------------------------------------

-- Query to delete a supplier from the Suppliers page
DELETE FROM Suppliers
WHERE supplier_id = :supplier_id_selected;

-- Query to delete an employee from the Employees page
DELETE FROM Employees
WHERE employee_id = :employee_id_selected;

-- Query to delete an item from the Media_Items page
DELETE FROM Media_Items
WHERE item_id = :item_id_selected;

-- Query to delete a creator from the Creators page
DELETE FROM Creators
WHERE creator_id = :creator_id_selected;

-- Query to delete a patron from the Patrons page
DELETE FROM Patrons
WHERE patron_id = :patron_id_selected;

-- Query to delete a transaction from the Media_Transactions page
-- Disassociating a patron from an item (M:N relationship deletion)
DELETE FROM Media_Transactions
WHERE patron_id = :patron_id_selected AND item_id = :item_id_selected
AND transaction_id = :transaction_id_selected;