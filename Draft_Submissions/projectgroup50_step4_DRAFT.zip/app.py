"""
This module is used to start the Local Library Database Maintenance Flask
application. It can be started by typing the following command into a terminal:

    Windows: python app.py
    MacOS: python3 app.py
"""

import os
import string_queries as sq
from datetime import datetime, timedelta
from flask import Flask, redirect, render_template, request, flash
from flask_mysqldb import MySQL

app = Flask(__name__)

app.config['MYSQL_HOST'] = 'classmysql.engr.oregonstate.edu'
app.config['MYSQL_USER'] = 'cs340_kraatzk'
app.config['MYSQL_PASSWORD'] = '9387'  # last 4 of onid
app.config['MYSQL_DB'] = 'cs340_kraatzk'
app.config['MYSQL_CURSORCLASS'] = "DictCursor"
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SECRET_KEY'] = "super secret key"
app.config['TEMPLATES_AUTO_RELOAD'] = True

mysql = MySQL(app)


@app.route("/")
def home():
    """Renders the HTML for the main page of the website.

    Returns:
        Str: The rendered HTML for the main page.
    """
    return render_template('index.j2')


@app.route("/creators", methods=["GET", "POST"])
def creators():
    """
    Renders the HTML for the creators page of the website. If the method is GET
    then the page will be rendered with all creators shown. If the method is
    POST then search results from the page will be used to return a custom
    result.

    Returns:
        Str: The rendered HTML for the creators page.
    """
    cur = mysql.connection.cursor()

    if request.method == "GET":
        # display results here
        header = sq.creators_query_headers()
        cur.execute(header)
        headers = cur.fetchall()
        search = sq.get_creators_query_results()
        cur.execute(search)
        search_results = cur.fetchall()

        return render_template('creators.j2', headers=headers,
                               search_results=search_results)

    if request.method == "POST":
        # return just the headers until a search is done.
        header = sq.creators_query_headers()
        cur.execute(header)
        headers = cur.fetchall()

        creator_id = request.form.get('creator_id_lookup')
        full_name = request.form.get('creator_full_name_lookup')

        if creator_id == "" or creator_id is None:
            creator_id = "%"
        if full_name == "" or full_name is None:
            full_name = "%"

        search_query = sq.post_creators_query_results()

        cur.execute(search_query, (creator_id, full_name))
        search_results = cur.fetchall()

        if len(search_results) == 0:
            flash("No search results found.")

        return render_template('creators.j2', headers=headers,
                               search_results=search_results)

    return render_template('index.j2')


@app.route("/new_creator", methods=["POST"])
def new_creator():
    """Add a new creator.

    Used to send values from the creators page to the database to add a new
    Creator. Once the data is added to the database, the page is redirected
    to the Creators page.

    Returns:
        Str: The rendered HTML for the creators page.
    """
    cur = mysql.connection.cursor()
    full_name = request.form.get('full_name')
    insert = sq.new_creator_insert_query()
    cur.execute(insert, (full_name,))
    mysql.connection.commit()

    return redirect("/creators")


@app.route("/delete_creator/<int:delete_id>", methods=["GET", "POST"])
def delete_creator(delete_id):
    """Delete a creator from the database.

    Returns:
        Str: The rendered HTML for the creators page.
    """

    cur = mysql.connection.cursor()
    delete = sq.delete_creator_query()
    cur.execute(delete, (delete_id,))
    mysql.connection.commit()

    return redirect("/creators")


@app.route("/edit_creator/<int:edit_id>", methods=["POST", "GET"])
def edit_creator(edit_id=None):
    """
    Used to edit the contents of a creator entry in the database. If the
    request method is GET, the contents of the creator entry are loaded into
    the edit page for the user. If the method is POST, then the results of
    the update are sent to the database.

    Args:
        edit_id: The ID of the creator to edit

    Returns:
        Str: The rendered HTML for the creators page.
    """

    cur = mysql.connection.cursor()
    if request.method == "GET":

        header = sq.creators_query_headers()
        cur.execute(header)
        headers = cur.fetchall()

        find = sq.get_edit_creators_find_query()
        cur.execute(find, (edit_id,))
        creator = cur.fetchall()

        return render_template('edit_creator.j2',
                               headers=headers, creator=creator)

    if request.method == "POST":

        creator_id = request.form.get('edit_creator_id')
        full_name = request.form.get('edit_creator_full_name')

        update = sq.post_edit_creators_update_query()
        cur.execute(update, (full_name, creator_id))
        mysql.connection.commit()

        return redirect("/creators")

    return render_template("index.j2")


@app.route("/suppliers", methods=["GET", "POST"])
def suppliers():
    """
    Renders the HTML for the suppliers page of the website. If the method is
    GET then the page will be rendered with all suppliers shown. If the method
    is POST then search results from the page will be used to return a custom
    result.

    Returns:
        str: The HTML to render the suppliers page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":
        
        header = sq.suppliers_header_query()
        cur.execute(header)
        headers = cur.fetchall()
        
        results = sq.get_suppliers_results_query()
        cur.execute(results)
        search_results = cur.fetchall()

        return render_template('suppliers.j2', headers=headers,
                               search_results=search_results)

    if request.method == "POST":
        # return just the headers until a search is done.
        header = sq.suppliers_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        supplier_id = request.form.get('supplier_id_lookup')
        supplier_name = request.form.get('supplier_name_lookup')
        phone_number = request.form.get('supplier_phone_number_lookup')

        if supplier_id == "" or supplier_id is None:
            supplier_id = "%"
        if supplier_name == "" or supplier_name is None:
            supplier_name = "%"
        if phone_number == "" or phone_number is None:
            phone_number = "%"

        
        search = sq.post_suppliers_results_query()
        params = (supplier_id, supplier_name, phone_number)
        cur.execute(search, params)
        search_results = cur.fetchall()

        if len(search_results) == 0:
            flash("No search results found.")

        return render_template('suppliers.j2', headers=headers,
                               search_results=search_results)

    return render_template('index.j2')


@app.route("/new_supplier", methods=["GET", "POST"])
def new_supplier():
    """
    Used to send values from the suppliers page to the database to add a new
    Supplier. Once the data is added to the database, the page is redirected
    to the Suppliers page.

    Returns:
        Str: The rendered HTML for the suppliers page.
    """
    cur = mysql.connection.cursor()
    supplier_name = request.form.get('supplier_name')
    supplier_address = request.form.get('supplier_address')
    phone_number = request.form.get('phone_number')

    insert = sq.new_suppliers_insert_query()
    params = (supplier_name, supplier_address, phone_number)

    cur.execute(insert, params)
    mysql.connection.commit()

    return redirect("/suppliers")


@app.route("/delete_supplier/<int:delete_id>", methods=["POST", "GET"])
def delete_supplier(delete_id):
    """Delete a supplier from the database.

    Returns:
        Str: The rendered HTML for the suppliers page.
    """
    cur = mysql.connection.cursor()
    delete = sq.delete_suppliers_query()
    cur.execute(delete, (delete_id,))
    mysql.connection.commit()

    return redirect("/suppliers")


@app.route("/edit_supplier/<int:edit_id>", methods=["POST", "GET"])
def edit_supplier(edit_id=None):
    """
        Used to edit the contents of a supplier entry in the database. If the
        request method is GET, the contents of the supplier entry are loaded
        into the edit page for the user. If the method is POST, then the
        results of the update are sent to the database.

        Args:
            edit_id: The ID of the supplier to edit

        Returns:
            Str: The rendered HTML for the suppliers page.
        """
    cur = mysql.connection.cursor()
    if request.method == "GET":

        header = sq.suppliers_header_query()
        cur.execute(header)
        headers = cur.fetchall()
        
        find = sq.get_edit_suppliers_find_query()
        cur.execute(find, (edit_id,))
        supplier = cur.fetchall()

        return render_template('edit_supplier.j2', headers=headers,
                               supplier=supplier)

    if request.method == "POST":

        supplier_id = request.form.get('edit_supplier_id')
        supplier_name = request.form.get('edit_supplier_name')
        supplier_address = request.form.get('edit_supplier_address')
        phone_number = request.form.get('edit_supplier_phone_number')

        params = (supplier_name, supplier_address, phone_number, supplier_id)
        update = sq.post_edit_suppliers_update_query()
        cur.execute(update, params)
        mysql.connection.commit()

        return redirect("/suppliers")

    return render_template('index.j2')


@app.route("/employees", methods=["GET", "POST"])
def employees():
    """
    Renders the HTML for the employees page of the website. If the method is
    GET then the page will be rendered with all employees shown. If the method
    is POST then search results from the page will be used to return a custom
    result.

    Returns:
        str: The HTML to render the employees page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":

        header = sq.employee_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        results = sq.get_employee_results_query()
        cur.execute(results)
        search_results = cur.fetchall()

        return render_template('employees.j2', headers=headers,
                               search_results=search_results)

    if request.method == "POST":
        # return just the headers until a search is done.
        header = sq.employee_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        employee_id = request.form.get('employee_id_lookup')
        first_name = request.form.get('employee_first_name_lookup')
        last_name = request.form.get('employee_last_name_lookup')
        phone_number = request.form.get('employee_phone_number_lookup')

        if employee_id == "" or employee_id is None:
            employee_id = "%"
        if first_name == "" or first_name is None:
            first_name = "%"
        if last_name == "" or last_name is None:
            last_name = "%"
        if phone_number == "" or phone_number is None:
            phone_number = "%"

        search = sq.post_employee_results_query()
        params = (employee_id, first_name, last_name, phone_number)
        cur.execute(search, params)
        search_results = cur.fetchall()

        if len(search_results) == 0:
            flash("No search results found.")

        return render_template('employees.j2', headers=headers,
                               search_results=search_results)

    return render_template('index.j2')


@app.route("/new_employee", methods=["GET", "POST"])
def new_employee():
    """
    Used to send values from the employees page to the database to add a new
    Employee. Once the data is added to the database, the page is redirected
    to the Employees page.

    Returns:
        Str: The rendered HTML for the employee page.
    """
    cur = mysql.connection.cursor()
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    phone_number = request.form.get('phone_number')
    address = request.form.get('address')

    if phone_number == "" or phone_number is None:
            phone_number = None;

    insert = sq.new_employee_insert_query()
    params = (first_name, last_name, phone_number, address)

    cur.execute(insert, params)
    mysql.connection.commit()

    return redirect("/employees")


@app.route("/delete_employee/<int:delete_id>", methods=["POST", "GET"])
def delete_employee(delete_id):
    """Delete an employee from the database.

    Returns:
        Str: The rendered HTML for the employee page.
    """
    cur = mysql.connection.cursor()
    delete = sq.delete_employee_query()
    cur.execute(delete, (delete_id,))
    mysql.connection.commit()

    return redirect("/employees")


@app.route("/edit_employee/<int:edit_id>", methods=["POST", "GET"])
def edit_employee(edit_id=None):
    """
    Used to edit the contents of an employee entry in the database. If the
    request method is GET, the contents of the employee entry are loaded
    into the edit page for the user. If the method is POST, then the
    results of the update are sent to the database.

    Args:
        edit_id: The ID of the employee to edit

    Returns:
        Str: The rendered HTML for the Employees page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":

        header = sq.employee_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        find = sq.get_edit_employee_find_query()
        cur.execute(find, (edit_id,))
        employee = cur.fetchall()

        return render_template('edit_employee.j2', headers=headers,
                               employee=employee)

    if request.method == "POST":

        employee_id = request.form.get('edit_employee_id')
        first_name = request.form.get('edit_employee_first_name')
        last_name = request.form.get('edit_employee_last_name')
        phone_number = request.form.get('edit_employee_phone_number')
        address = request.form.get('edit_employee_address')

        if phone_number == "" or phone_number is None:
            phone_number = None;

        params = (first_name, last_name, phone_number, address, employee_id)
        update = sq.post_edit_employee_update_query()
        cur.execute(update, params)
        mysql.connection.commit()

        return redirect("/employees")

    return render_template('index.j2')


@app.route("/patrons", methods=["GET", "POST"])
def patrons():
    """
    Renders the HTML for the patrons page of the website. If the method is GET
    then the page will be rendered with all patrons shown. If the method is
    POST then search results from the page will be used to return a custom
    result.

    Returns:
        Str: The rendered HTML for the patrons page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":
        # display results here
        
        header = sq.patrons_query_headers()
        cur.execute(header)
        headers = cur.fetchall()

        search = sq.get_patrons_query_results()
        cur.execute(search)
        search_results = cur.fetchall()

        return render_template('patrons.j2', headers=headers,
                               search_results=search_results)

    if request.method == "POST":
        # return just the headers until a search is done.
        header = sq.patrons_query_headers()
        cur.execute(header)
        headers = cur.fetchall()

        patron_id = request.form.get('patron_id_lookup')
        first_name = request.form.get('patron_first_name_lookup')
        last_name = request.form.get('patron_last_name_lookup')
        phone_number = request.form.get('patron_phone_number_lookup')

        if patron_id == "" or patron_id is None:
            patron_id = "%"
        if first_name == "" or first_name is None:
            first_name = "%"
        if last_name == "" or last_name is None:
            last_name = "%"
        if phone_number == "" or phone_number is None:
            phone_number = "%"

        
        search = sq.post_patrons_query_results()
        params = (patron_id, first_name, last_name, phone_number)
        cur.execute(search, params)
        search_results = cur.fetchall()

        if len(search_results) == 0:
            flash("No search results found.")

        return render_template('patrons.j2', headers=headers,
                               search_results=search_results)

    return render_template('index.j2')


@app.route("/new_patron", methods=["POST"])
def new_patron():
    """Add a new patron.

    Used to send values from the patrons page to the database to add a new
    Patron. Once the data is added to the database, the page is redirected
    to the Patrons page.

    Returns:
        Str: The rendered HTML for the patrons page.
    """
    cur = mysql.connection.cursor()
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    phone_number = request.form.get('phone_number')
    fine_amount = request.form.get('fine_amount')
    address = request.form.get('address')

    if fine_amount == "" or fine_amount is None:
            fine_amount = None;

    insert = sq.new_patrons_insert_query()
    params = (first_name, last_name, phone_number, fine_amount, address)
    cur.execute(insert, params)
    mysql.connection.commit()

    return redirect("/patrons")


@app.route("/delete_patron/<int:delete_id>", methods=["GET", "POST"])
def delete_patron(delete_id):
    """Delete a patron from the database.

    Returns:
        Str: The rendered HTML for the patrons page.
    """

    cur = mysql.connection.cursor()
    delete = sq.delete_patrons_query()
    cur.execute(delete, (delete_id,))
    mysql.connection.commit()

    return redirect("/patrons")


@app.route("/edit_patron/<int:edit_id>", methods=["POST", "GET"])
def edit_patron(edit_id=None):
    """
    Used to edit the contents of a patron entry in the database. If the
    request method is GET, the contents of the patron entry are loaded into
    the edit page for the user. If the method is POST, then the results of
    the update are sent to the database.

    Args:
        edit_id: The ID of the patron to edit

    Returns:
        Str: The rendered HTML for the patrons page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":
        
        header = sq.patrons_query_headers()
        cur.execute(header)
        headers = cur.fetchall()

        find = sq.get_edit_patrons_find_query()
        cur.execute(find, (edit_id,))
        patron = cur.fetchall()

        return render_template('edit_patron.j2',
                               headers=headers, patron=patron)

    if request.method == "POST":

        patron_id = request.form.get('edit_patron_id')
        first_name = request.form.get('edit_patron_first_name')
        last_name = request.form.get('edit_patron_last_name')
        phone_number = request.form.get('edit_patron_phone_number')
        fine_amount = request.form.get('edit_patron_fine_amount')
        address = request.form.get('edit_patron_address')

        if fine_amount == "" or fine_amount is None:
            fine_amount = None;
        
        update = sq.post_edit_patrons_update_query()
        params = (first_name, last_name, phone_number, fine_amount, address, patron_id)
        cur.execute(update, params)
        mysql.connection.commit()

        return redirect("/patrons")

    return render_template("index.j2")


@app.route("/media_items", methods=["GET", "POST"])
def media_items():
    """
    Renders the HTML for the media items page of the website. If the method is
    GET then the page will be rendered with all items shown. If the method
    is POST then search results from the page will be used to return a custom
    result.

    Returns:
        str: The HTML to render the media items page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":
        header = sq.media_items_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        search = sq.get_media_items_results_query()
        cur.execute(search)
        search_results = cur.fetchall()

        return render_template('media_items.j2', headers=headers,
                               search_results=search_results)

    if request.method == "POST":
        # return just the headers until a search is done.
        header = sq.media_items_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        item_id = request.form.get('media_item_id_lookup')
        media_type = request.form.get('media_type_lookup')
        supplier_id = request.form.get('media_supplier_id_lookup')
        title = request.form.get('title_lookup')
        creator_id = request.form.get('media_creator_id_lookup')

        if item_id == "" or item_id is None:
            item_id = "%"
        if media_type == "" or media_type is None:
            media_type = "%"
        if supplier_id == "" or supplier_id is None:
            supplier_id = "%"
        if title == "" or title is None:
            title = "%"
        if creator_id == "" or creator_id is None:
            creator_id = "%"

        search = sq.post_media_items_search_query()

        params = (item_id, media_type, supplier_id, title, creator_id)

        cur.execute(search, params)
        search_results = cur.fetchall()

        if len(search_results) == 0:
            flash("No search results found.")

        return render_template('media_items.j2', headers=headers,
                               search_results=search_results)

    return render_template('index.j2')

@app.route("/new_media_item", methods=["GET", "POST"])
def new_media_item():
    """
    Used to send values from the media items page to the database to add a new
    media item. Once the data is added to the database, the page is redirected
    to the media items page.

    Returns:
        Str: The rendered HTML for the media items page.
    """
    cur = mysql.connection.cursor()
    media_type = request.form.get('media_type')
    supplier_id = request.form.get('supplier_id')
    title = request.form.get('title')
    creator_id = request.form.get('creator_id')
    release_date = request.form.get('release_date')
    replacement_cost = request.form.get('replacement_cost')
    quantity_owned = request.form.get('quantity_owned')

    if supplier_id == "" or supplier_id is None:
        supplier_id = None;

    if replacement_cost == "" or replacement_cost is None:
        replacement_cost = None;

    insert = sq.new_media_item_insert_query()

    params = (media_type, supplier_id, title, creator_id, release_date,
              replacement_cost, quantity_owned)

    cur.execute(insert, params)
    mysql.connection.commit()

    return redirect("/media_items")

@app.route("/delete_media_item/<int:delete_id>", methods=["POST", "GET"])
def delete_media_item(delete_id):
    """Delete a media item from the database.

    Returns:
        Str: The rendered HTML for the media items page.
    """
    cur = mysql.connection.cursor()
    delete_query = sq.delete_media_item_query()
    cur.execute(delete_query, (delete_id,))
    mysql.connection.commit()

    return redirect("/media_items")

@app.route("/edit_media_item/<int:edit_id>", methods=["POST", "GET"])
def edit_media_item(edit_id=None):
    """
        Used to edit the contents of a media item entry in the database. If the
        request method is GET, the contents of the media item entry are loaded
        into the edit page for the user. If the method is POST, then the
        results of the update are sent to the database.

        Args:
            edit_id: The ID of the media item to edit

        Returns:
            Str: The rendered HTML for the Media Items page.
        """
    cur = mysql.connection.cursor()
    if request.method == "GET":

        header = sq.media_items_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        find = sq.edit_media_item_find_query()
        cur.execute(find, (edit_id,))
        item = cur.fetchall()

        get_supplier_ids = sq.get_supplier_ids_query()
        cur.execute(get_supplier_ids)
        ids = cur.fetchall()

        return render_template('edit_media_item.j2', headers=headers,
                               item=item, ids=ids)

    if request.method == "POST":

        item_id = request.form.get('item_id')
        media_type = request.form.get('media_type')
        supplier_id = request.form.get('supplier_id')
        title = request.form.get('title')
        creator_id = request.form.get('creator_id')
        release_date = request.form.get('release_date')
        replacement_cost = request.form.get('replacement_cost')
        quantity_owned = request.form.get('quantity_owned')

        if supplier_id == "" or supplier_id is None:
            supplier_id = None;

        if replacement_cost == "" or replacement_cost is None:
            replacement_cost = None;

        params = (media_type, supplier_id, title, creator_id, release_date,
                  replacement_cost, quantity_owned, item_id)

        update = sq.post_edit_media_item_query()
        cur.execute(update, params)
        mysql.connection.commit()

        return redirect("/media_items")

    return render_template('index.j2')


@app.route("/media_transactions", methods=["GET", "POST"])
def media_transactions():
    """Displays the media transactions page.

    Returns:
        str: The rendered HTML for the media transactions page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":
        header = sq.media_transactions_header_query()
        cur.execute(header)
        headers = cur.fetchall()
        search = sq.get_media_transactions_all_checkouts_query()
        cur.execute(search)
        search_results = cur.fetchall()

        return render_template('media_transactions.j2', headers=headers,
                               search_results=search_results)

    if request.method == "POST":

        patron_id = request.form.get("transaction_patron_id_lookup")
        employee_id = request.form.get('transaction_employee_id_lookup')
        transaction_type = request.form.get('transaction_type_lookup')
        item_id = request.form.get('transaction_item_id_lookup')
        transaction_date = request.form.get('transaction_date_lookup')
        get_history = request.form.get('get_all_history')
        next_day = datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M:%S")

        if patron_id == "" or patron_id is None:
            patron_id = "%"
        if employee_id == "" or employee_id is None:
            employee_id = "%"
        if transaction_type == "" or transaction_type is None:
            transaction_type = "%"
        if item_id == "" or item_id is None:
            item_id = "%"
        if transaction_date == "" or transaction_date is None:
            transaction_date = "1970-01-01 00:00:01"
        else:
            transaction_date = datetime.strptime(transaction_date,
                                                 "%Y-%m-%d")
            next_day = transaction_date + timedelta(days=1)
            transaction_date = datetime.strftime(transaction_date,
                                                 "%Y-%m-%d %H:%M:%S")
            next_day = datetime.strftime(next_day,
                                         "%Y-%m-%d %H:%M:%S")

        header = sq.media_transactions_header_query()
        cur.execute(header)
        headers = cur.fetchall()
        if get_history == "on":
            search = sq.get_all_media_transactions_custom_query()
        else:
            search = sq.post_media_transactions_checkouts_custom_query()

        params = (patron_id, employee_id, transaction_type, item_id,
                  transaction_date, next_day)

        cur.execute(search, params)
        search_results = cur.fetchall()

        if len(search_results) == 0:
            flash("No search results found.")

        return render_template('media_transactions.j2', headers=headers,
                               search_results=search_results)

    return render_template('media_transactions.j2')


@app.route("/new_media_transaction", methods=["GET", "POST"])
def new_media_transaction():
    """
    Used to send values from the media transactions page to the database to
    add a new media transaction. Once the data is added to the database, the
    page is redirected to the media transactions page.

    Returns:
        Str: The rendered HTML for the media transactions page.
    """
    cur = mysql.connection.cursor()
    patron_id = request.form.get('patron_id')
    transaction_type = request.form.get('transaction_type')
    employee_id = request.form.get('employee_id')
    item_id = request.form.get('item_id')
    transaction_date = (datetime.now()).strftime('%Y-%m-%d %H:%M:%S')

    insert = sq.new_media_transaction_insert_query()

    params = (patron_id, transaction_type, employee_id, item_id,
              transaction_date)

    cur.execute(insert, params)
    mysql.connection.commit()

    return redirect("/media_transactions")

@app.route("/edit_media_transaction/<int:edit_id>", methods=["POST", "GET"])
def edit_media_transaction(edit_id=None):
    """
    Used to edit the contents of a media transaction entry in the database.
    If the request method is GET, the contents of the media transaction
    entry are loaded into the edit page for the user. If the method is
    POST, then the results of the update are sent to the database.

    Args:
        edit_id: The ID of the media transaction to edit

    Returns:
        Str: The rendered HTML for the media transactions page.
    """
    cur = mysql.connection.cursor()
    if request.method == "GET":

        header = sq.media_transactions_header_query()
        cur.execute(header)
        headers = cur.fetchall()

        find = sq.edit_media_transaction_find_query()

        cur.execute(find, (edit_id,))
        transaction = cur.fetchall()

        return render_template('edit_media_transaction.j2', headers=headers,
                               transaction=transaction)

    if request.method == "POST":

        patron_id = request.form.get('edit_patron_id')
        transaction_type = request.form.get('edit_transaction_type')
        employee_id = request.form.get('edit_employee_id')
        item_id = request.form.get('edit_item_id')

        params = (patron_id, transaction_type, employee_id, item_id,
                  edit_id)

        update = sq.post_edit_media_transaction_update_query()
        cur.execute(update, params)
        mysql.connection.commit()

        return redirect("/media_transactions")

    return render_template('index.j2')

@app.route("/delete_media_transaction/<int:delete_id>", methods=["POST", "GET"])
def delete_media_transaction(delete_id):
    """Delete a media transaction from the database.

    Returns:
        Str: The rendered HTML for the media transaction page.
    """
    cur = mysql.connection.cursor()
    delete = sq.delete_media_transaction_query()
    cur.execute(delete, (delete_id,))
    mysql.connection.commit()

    return redirect("/media_transactions")


if __name__ == "__main__":
    port = int(os.environ.get('PORT', 53266))

    app.run(debug=True, port=port)